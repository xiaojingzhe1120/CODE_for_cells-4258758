
## ── 0) 工作目录 & 环境 ────────────────────────────────────────────────────
suppressMessages({
  if (identical(getOption("repos")["CRAN"], "@CRAN@"))
    options(repos = c(CRAN = "https://cloud.r-project.org"))
  need <- c("data.table","future.apply")
  for (p in need) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
  library(data.table)
  library(future.apply)
})

options(
  datatable.print.nrows = 50L,
  scipen = 999,
  datatable.fread.datatable = TRUE
)


nc <- parallel::detectCores(logical = TRUE)
dt_threads <- max(1L, floor(nc/4))  # 你有 16 逻辑核时，这里给 4；可按需调大
data.table::setDTthreads(dt_threads)

# 如果你装了 RhpcBLASctl，可限制 BLAS 线程，避免与并行进程抢核
if (requireNamespace("RhpcBLASctl", quietly = TRUE)) {
  RhpcBLASctl::blas_set_num_threads(1L)
  RhpcBLASctl::omp_set_num_threads(1L)
}

# RStudio 下自动定位到脚本目录（可保留）
if (requireNamespace("rstudioapi", quietly = TRUE)) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
}

## ── 1) 参数 ───────────────────────────────────────────────────────────────
inputFile <- c("EXERCISE_Fixed_hg19", "T2D_Fixed_hg19")
gtex_tissue_names <- c(
  "Adipose_Subcutaneous","Adipose_Visceral_Omentum","Heart_Atrial_Appendage",
  "Heart_Left_Ventricle","Kidney_Cortex","Liver","Lung","Pancreas",
  "Muscle_Skeletal","Whole_Blood"
)
qtl_types <- c("eQTL","sQTL")
resources <- c("GO_MF","GO_BP","GO_CC","KEGG","REACTOME","MGI","HALLMARK")

# 参考文件
gtf_file <- "../03.reference/GeneEnrich/gencode.v26.annotation.gtf"
HLA_file <- "../03.reference/GeneEnrich/HLA_region_file_hg38.tsv"
gene_set_dir <- "../03.reference/GeneEnrich"

# 输出目录
if (!dir.exists("./result")) dir.create("./result", recursive = TRUE)

## ── 2) 生成任务清单（展开三重循环） ─────────────────────────────────────────
qtlenrich_base <- function(qtl) {
  switch(qtl,
         "eQTL" = "../08.QTLEnrich_eQTL/result/GeneEnrich_Input_Files/GeneEnrich_input_best_eqtl_Tissue_",
         "sQTL" = "../09.QTLEnrich_sQTL/result/GeneEnrich_Input_Files/GeneEnrich_input_best_sqtl_Tissue_",
         stop("未知 qtl_type"))
}

tasks <- rbindlist(lapply(inputFile, function(trait) {
  rbindlist(lapply(qtl_types, function(qtl){
    base <- qtlenrich_base(qtl)
    rbindlist(lapply(gtex_tissue_names, function(tissue){
      sig <- paste0(base, tissue, "_", trait, "_", trait, "_significant.txt")
      nul <- paste0(base, tissue, "_", trait, "_", trait, "_null.txt")
      # 只保留存在的任务
      if (file.exists(sig) && file.exists(nul)) {
        data.table(trait = trait, qtl = qtl, tissue = tissue,
                   significant = sig, null = nul)
      } else {
        NULL
      }
    }))
  }))
}))

if (nrow(tasks) == 0L) stop("未发现可用的 QTLEnrich 输入，请先检查上游结果。")

# 与资源做笛卡尔积
tasks <- tasks[, .(resource = resources), by = .(trait, qtl, tissue, significant, null)]
# 生成输出名与“已完成”判定（优先判定结果，其次判定日志）
tasks[, `:=`(
  outname = paste(trait, qtl, tissue, resource, sep = "_"),
  gene_set_file = file.path(gene_set_dir, paste0(resource, "_genesets.txt"))
)]
tasks[, `:=`(
  result_glob = file.path("./result", paste0("GeneEnrich_", outname, ".*_results.tsv")),
  log_glob    = file.path("./result", paste0("GeneEnrich_", outname, ".*_log.txt"))
)]

# 过滤掉已经完成的任务（存在任一匹配文件即视为完成）
is_done <- function(glob) length(Sys.glob(glob)) > 0L
tasks <- tasks[!(vapply(result_glob, is_done, logical(1)) | vapply(log_glob, is_done, logical(1)))]

if (nrow(tasks) == 0L) {
  message("✅ 所有任务均已完成，无需重复运行。")
  quit(save = "no")
}

## ── 3) 并行计划 ────────────────────────────────────────────────────────────
# Linux/WSL 建议 multicore；Windows 用 multisession
plan_choice <- if (.Platform$OS.type == "windows") "multisession" else "multicore"
future::plan(plan_choice, workers = max(1L, floor(nc / 2)))  # 一半核做外层并行，另一半留给 data.table

## ── 4) 核心执行函数（单个任务） ────────────────────────────────────────────
run_one <- function(trait, qtl, tissue, significant, null, resource,
                    outname, gene_set_file,
                    gtf_file, HLA_file) {
  # 再次短路：若并发期间已有人跑完
  if (length(Sys.glob(file.path("./result", paste0("GeneEnrich_", outname, ".*_log.txt")))) > 0L ||
      length(Sys.glob(file.path("./result", paste0("GeneEnrich_", outname, ".*_results.tsv")))) > 0L) {
    return(list(outname = outname, status = "skip-exists"))
  }
  
  # 每个任务独立临时文件，彻底避免并发覆盖
  sig_tmp <- tempfile(pattern = "sig_", fileext = ".txt")
  nul_tmp <- tempfile(pattern = "nul_", fileext = ".txt")
  
  # 只读一次并改列名（data.table 内部多线程已按 setDTthreads 设置）
  sig_dt <- tryCatch(fread(significant, showProgress = FALSE), error = function(e) e)
  nul_dt <- tryCatch(fread(null, showProgress = FALSE), error = function(e) e)
  if (inherits(sig_dt, "error") || inherits(nul_dt, "error")) {
    return(list(outname = outname, status = "read-error"))
  }
  
  # 改列名（不会复制内存）
  if (all(c("eVariant","eGene") %in% names(sig_dt))) {
    setnames(sig_dt, c("eVariant","eGene"), c("variant","gene"), skip_absent = TRUE)
  } else if (!all(c("variant","gene") %in% names(sig_dt))) {
    return(list(outname = outname, status = "bad-sig-header"))
  }
  if ("eGene" %in% names(nul_dt)) setnames(nul_dt, "eGene", "gene", skip_absent = TRUE)
  if (!("gene" %in% names(nul_dt))) {
    return(list(outname = outname, status = "bad-null-header"))
  }
  
  # 写临时输入（内核缓存里，极快；避免反复写相同文件名）
  fwrite(sig_dt, sig_tmp, sep = "\t", quote = FALSE, showProgress = FALSE)
  fwrite(nul_dt, nul_tmp, sep = "\t", quote = FALSE, showProgress = FALSE)
  
  # 调 GeneEnrich（尽量少打印，避免并发 IO 抢锁）
  # 使用 tryCatch，失败也能复现并定位
  res <- tryCatch({
    Fast2TWAS::GeneEnrich_run(
      significant_genes = sig_tmp,
      null_genes        = nul_tmp,
      gene_set_file     = gene_set_file,
      min_permutations  = 1000,
      max_permutations  = 100000,
      gtf_file          = gtf_file,
      resource_name     = resource,
      is_restrict_genes_database = TRUE,
      is_HLA_remove     = TRUE,
      HLA_file          = HLA_file,
      gene_set_size_min = NULL,
      gene_set_size_max = NULL,
      is_fast_permute   = TRUE,
      bed_remove        = NULL,
      p_val_cutoff      = NULL,
      q_val_cutoff      = NULL,
      fdr_cutoff        = NULL,
      genes_to_mark_table = NULL,
      mark_columns      = NULL,
      gene_expression_levels = NULL,
      tissue_of_interest   = NULL,
      is_development    = FALSE,
      is_null_set       = FALSE,
      is_sig_gs_cutoff  = FALSE,
      is_help           = FALSE,
      force             = FALSE,
      outname           = outname
    )
    "ok"
  }, error = function(e) paste0("fail: ", conditionMessage(e)))
  
  # 清理临时文件
  unlink(c(sig_tmp, nul_tmp), force = TRUE)
  
  list(outname = outname, status = res)
}

## ── 5) 并行执行 ────────────────────────────────────────────────────────────
# 以列表输入，避免 data.frame -> list 的复制开销
## ── 5) 并行执行 ────────────────────────────────────────────────────────────
# 每个元素是一行任务；split 返回的一行仍是 data.table/data.frame
job_list <- split(tasks, seq_len(nrow(tasks)))

ans <- future_lapply(
  job_list,
  function(x) {
    # 方式一：直接用 x[[ "colname" ]] 访问列（长度为 1 的向量）
    run_one(
      trait         = x[["trait"]],
      qtl           = x[["qtl"]],
      tissue        = x[["tissue"]],
      significant   = x[["significant"]],
      null          = x[["null"]],
      resource      = x[["resource"]],
      outname       = x[["outname"]],
      gene_set_file = x[["gene_set_file"]],
      gtf_file      = gtf_file,
      HLA_file      = HLA_file
    )
    
    # 如果你更喜欢“纯列表”，也可以：
    # xl <- as.list(x);  # 转成列列表
    # run_one(
    #   trait = xl$trait, qtl = xl$qtl, tissue = xl$tissue,
    #   significant = xl$significant, null = xl$null, resource = xl$resource,
    #   outname = xl$outname, gene_set_file = xl$gene_set_file,
    #   gtf_file = gtf_file, HLA_file = HLA_file
    # )
  },
  future.seed = TRUE,      # 保持置换的可复现性
  future.chunk.size = 1L   # 避免超大任务捆绑影响调度
)


## ── 6) 汇总 & 提示 ─────────────────────────────────────────────────────────
ans_dt <- rbindlist(lapply(ans, as.data.table), fill = TRUE)
print(ans_dt[, .N, by = status][order(-N)])
message("✅ 完成：", sum(ans_dt$status == "ok"),
        "；跳过：", sum(grepl("^skip", ans_dt$status)),
        "；失败：", sum(grepl("^fail|error|bad", ans_dt$status)))
################################################################################
