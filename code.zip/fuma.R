library(data.table)
stable6<-fread("E:/13.fuma/stable6.txt")
stable6_select<-fread("E:/13.fuma/stable6_select.txt")

head(stable6)
head(stable6_select)
# 目标列顺序（参考 stable6）
target_order <- c("rsID","Trait","GWAS_locus","hg19","CHR","hg38",
                  "effect_allele","other_allele","eaf","beta","se","pval","N")

# 备份一份
s6  <- copy(stable6)
s6s <- copy(stable6_select)

# 统一列名到小写，便于匹配与重命名
setnames(s6s, old = names(s6s), new = tolower(names(s6s)))

# 检查并映射列：允许 stable6_select 的列名与下列同义
# 必需：rsid/rsID, trait, gwas_locus(可重建), hg19, chr, hg38, effect_allele, other_allele, eaf, beta, se, pval, n/N
syn_map <- list(
  rsid         = "rsID",
  trait        = "Trait",
  gwas_locus   = "GWAS_locus",
  hg19         = "hg19",
  chr          = "CHR",
  hg38         = "hg38",
  effect_allele= "effect_allele",
  other_allele = "other_allele",
  eaf          = "eaf",
  beta         = "beta",
  se           = "se",
  pval         = "pval",
  n            = "N"
)

# 若无 gwas_locus，后面会重建
need_now <- setdiff(c(names(syn_map)), c("gwas_locus"))
miss <- setdiff(need_now, names(s6s))
if (length(miss)) stop("stable6_select 缺少必要列：", paste(miss, collapse = ", "))

# 内容规范化 -------------------------------------------------------

# rsID：统一小写 rs 开头
s6s[, rsid := tolower(rsid)]
s6s[, rsid := sub("^rs", "rs", rsid, ignore.case = TRUE)]

# CHR：统一小写且带 'chr' 前缀
s6s[, chr := tolower(chr)]
s6s[!grepl("^chr", chr), chr := paste0("chr", chr)]

# 数值类型统一
num_cols <- intersect(c("hg19","hg38","eaf","beta","se","n"), names(s6s))
for (cc in num_cols) set(s6s, j = cc, value = as.numeric(s6s[[cc]]))
if ("n" %in% names(s6s)) s6s[, n := as.integer(round(n))]

# pval：转字符型科学计数法，与 stable6 风格一致（例如 "2.178e-08"）
s6s[, pval := formatC(as.numeric(pval), format = "e", digits = 3)]

# gwas_locus：规范为 "chr#:pos:effect:other"
if (!"gwas_locus" %in% names(s6s)) {
  s6s[, gwas_locus := paste(chr, as.integer(hg19), paste0(effect_allele, ":", other_allele), sep=":")]
} else {
  # 已有也重建一次确保格式统一
  s6s[, gwas_locus := paste(chr, as.integer(hg19), paste0(effect_allele, ":", other_allele), sep=":")]
}

# 去重（同一 Trait+rsID 保留一条）
setorder(s6s, trait, rsid)
s6s <- unique(s6s, by = c("trait","rsid"))

# 重命名为 stable6 的大小写 --------------------------
setnames(s6s,
         old = names(s6s),
         new = replace(names(s6s), match(names(s6s), names(s6s)),
                       vapply(names(s6s), function(nm){
                         if (nm %in% names(syn_map)) syn_map[[nm]] else nm
                       }, character(1))),
         skip_absent = TRUE
)

# 严格选列并按 target_order 排列（多余列丢弃，保证完全对齐）
keep <- intersect(target_order, names(s6s))
s6s_out <- s6s[, ..keep]
# 若有缺的列（极少见），补 NA 再重排
missing_final <- setdiff(target_order, names(s6s_out))
for (mc in missing_final) s6s_out[, (mc) := NA]
setcolorder(s6s_out, target_order)

# 类型对齐（参考 stable6 的前几行类型）
# stable6 示例显示：pval 为 <char>，其余数值/字符按例设置
type_fix <- function(dt){
  dt[, rsID          := as.character(rsID)]
  dt[, Trait         := as.character(Trait)]
  dt[, GWAS_locus    := as.character(GWAS_locus)]
  dt[, hg19          := as.integer(hg19)]
  dt[, CHR           := as.character(CHR)]
  dt[, hg38          := as.integer(hg38)]
  dt[, effect_allele := as.character(effect_allele)]
  dt[, other_allele  := as.character(other_allele)]
  dt[, eaf           := as.numeric(eaf)]
  dt[, beta          := as.numeric(beta)]
  dt[, se            := as.numeric(se)]
  dt[, pval          := as.character(pval)]   # 关键：字符
  dt[, N             := as.integer(N)]
  dt
}
s6s_out <- type_fix(s6s_out)

# 快速核对列名与类型 ------------------------------------------------
cat("stable6 列：\n"); print(str(s6[, ..target_order], give.attr = FALSE))
cat("对齐后列：\n"); print(str(s6s_out[, ..target_order], give.attr = FALSE))

# 导出（无行名、制表符、无引号）
out_path <- "E:/13.fuma/stable6_select_as_stable6.txt"
fwrite(s6s_out, out_path, sep = "\t", quote = FALSE)
cat("✅ 已输出：", out_path, "\n")

# 可视预览
head(s6s_out)
