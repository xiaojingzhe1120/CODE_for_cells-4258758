
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#加载包
library(Fast2TWAS)

#输入参数-----------------------------------------------------------------------
#性状名称
trait="EXERCISE"

#######MAC电脑中无法执行IVW随机效应（IVW:Additive random effects）##############
#指定GWAS数据meta时IVW的模型c("Fixed","Additive","Multiplicative")--------------
IVW_method="Fixed"

#导入meta分析结果路径
path="../0.6.5.METAgwas/result/"

#读入数据
dat=data.frame(data.table::fread(paste0(path,trait,"_meta.txt"),showProgress = T))

head(dat)

#生成Fast2TWAS::show_demo_gwas()格式数据----------------------------------------
if (IVW_method=="Fixed"){
  beta = "Effect"
  se = "StdErr"
  pval = "Pvalue"
} else if (IVW_method=="Additive") {
  beta="EffectARE"
  se="StdErrARE"
  pval="PvalueARE"
}else if (IVW_method=="Multiplicative") {
  beta="Effect"
  se="StdErrMRE"
  pval="PvalueMRE"
}

pre_fuma_data=dat[,c("CHR","BP","MarkerName","Allele1","Allele2","Freq1",beta,se,pval,"N")]
colnames(pre_fuma_data)=colnames(show_demo_gwas())
pre_fuma_data$effect_allele=toupper(pre_fuma_data$effect_allele)
pre_fuma_data$other_allele=toupper(pre_fuma_data$other_allele)
head(pre_fuma_data)

#保存数据
data.table::fwrite(pre_fuma_data,
                   file = paste0(trait,"_",IVW_method,"_hg19.txt"),
                   sep = "\t")
