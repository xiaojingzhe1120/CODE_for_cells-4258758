
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#加载包
library(Fast2TWAS)
library(data.table)

#Fast2TWAS包中建议的GWAS数据格式
show_demo_gwas()

#输入参数-----------------------------------------------------------------------
#性状名
inputFile=c("prot-c-2765_4_3.vcf.gz")
################################################################################
#######注意检查从IEU官网下载数据的完整性：######################################
#######1.运行过程中不要断网，电脑的内存尽量大一些###############################
#######2.下载过程中不要中断，否则下载的数据可能不完整###########################
#######3.IEU官网中的个别GWAS数据存在问题，很可能12号染色体不完整，注意检查######
################################################################################
# 从IEU读入下载数据，后续分析以IEU数据作为示例----------------------------------
data=read_ieu_data(ieu_id = paste0("../04.rawdata/",inputFile),
                   download = F,
                   #maf = 0.01, #删除maf<0.01的SNP
                   pvalue = NULL,
                   is_fast2twas_format = T)

#保存数据
fwrite(data,
       file = paste0(inputFile,".txt"),
       sep = "\t")
getwd()

################################################################################
# 芬兰数据的处理 ---------------------------------------------------------------
################################################################################
#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()

#输入性状名
inputFile="finngen_R12_T2D.gz"
trait="T2D"
N=486367

#finngen数据预处理生成建议的GWAS数据格式
data=finngenClean(finngenfile = paste0("../04.rawdata/",inputFile),
                  samplesize = N,
                  savefile = paste0(trait,".txt"))
head(data)

################################################################################
# 其他数据处理 -----------------------------------------------------------------
################################################################################
#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
# 输入性状名
inputFile="GCST90241346_GRCh37.tsv.gz"
trait="GDF11"
#读入数据
data <- fread(paste0("../04.rawdata/",inputFile))
#查看数据
head(data)
#数据预处理
data=gwas2format(gwas_dat  = data,
                 chr_col = "chromosome",               #GWAS数据中SNPs的染色体列名，默认CHR
                 pos_col = "base_pair_location",       #GWAS数据中SNPs的基因位置列名，默认BP
                 snp_col = "variant_id",               #GWAS数据中SNPs的rsid列名，默认SNP
                 effect_allele_col = "effect_allele",  #GWAS数据中SNPs的效应等位基因列名，默认effect_allele
                 other_allele_col = "other_allele",    #GWAS数据中SNPs的非效应等位基因列名，默认other_allele 
                 eaf_col = "eaf",                      #GWAS数据中SNPs的效应等位基因频率列名，默认eaf
                 beta_col = "beta",                    #GWAS数据中SNPs的效应值列名，默认beta
                 se_col = "standard_error",            #GWAS数据中SNPs的标准误差列名，默认se
                 pval_col = "p_value",                 #GWAS数据中SNPs的pval值列名，默认pval
                 log_pval = FALSE,                     #GWAS数据中SNPs的pval值是否为-log10(pval)，默认FALSE
                 ncase_col = "ncase",                  #GWAS数据中SNPs的病例数列名，默认ncase
                 ncontrol_col = "ncontrol",            #GWAS数据中SNPs的对照数列名，默认ncontrol
                 samplesize_col = "samplesize",        #GWAS数据中SNPs的总样本数列名，默认N
                 min_pval = 1e-300,                    #强制设置pval的最小值，默认为1e-200
                 samplesize = 383500)                  #强制设置GWAS数据中SNPs的总样本数，默认NULL

data$variant_id <- paste0(data$chromosome, ":", data$base_pair_location, ":", data$effect_allele, ":", data$other_allele)

data = gwas2format(
  gwas_dat  = data,
  chr_col = "chromosome",
  pos_col = "base_pair_location",
  snp_col = "variant_id",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  beta_col = "beta",
  se_col = "standard_error",
  pval_col = "p_value",
  log_pval = FALSE,
  samplesize = 383500
)

#查看数据
head(data)
#保存数据
fwrite(data,
       file = paste0(trait,".txt"),
       sep = "\t")
