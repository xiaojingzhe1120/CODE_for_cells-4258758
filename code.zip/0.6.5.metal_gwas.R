
setwd("/mnt/")
#设置当前工作路径
#Rsrudio打开该文件，根据R代码所在位置，设置所在文件夹为工作路径
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#加载包
library(Fast2TWAS)

#输入参数-----------------------------------------------------------------------
inputFile=c("ebi-a-GCST006100.vcf.gz","ukb-b-8764.vcf.gz")
#性状名称
trait="EXERCISE"

#######MAC电脑中无法执行IVW随机效应（IVW:Additive random effects）##############
#指定GWAS数据meta时IVW的模型c("Fixed","Additive","Multiplicative")--------------
IVW_method="Fixed"

# 是否只保留同时存在于多个原始gwas数据的SNPs的meta结果
in_all_gwas = FALSE
#####激活权限#######
####chmod +x /home/train/R/x86_64-pc-linux-gnu-library/4.5/friendlypostGWASsoft/bin/Linux/metal
#METAL进行meta分析 -------------------------------------------------------------
################################################################################
#######MAC电脑中无法执行随机效应（IVW:Additive random effects）#################
################################################################################
#metal软件可以meta多个GWAS数据，GWAS数据基因组版本最好相同
#which_IVW_mode选择返回哪一种效应，c("Additive","Multiplicative","Fixed")，默认为Fixed时为固定效应
dat=metal_gwas(gwasfiles = paste0("/mnt/e/06.pre_data/" ,trait,"_",inputFile,".txt"), 
               is_with_chrBP = T,
               Filter_MAF = 0.01,         #minor allele frequency > 0.01
               which_format = NULL,
               which_IVW_mode = IVW_method,
               outname = trait)


#是否只保留同时存在于多个gwas数据的SNPs的meta结果-------------------------------
if(in_all_gwas) {
  dat_all_SNP <-dat[!grepl("\\?", dat$Direction),]
  #保存数据
  data.table::fwrite(dat_all_SNP,
                     file = paste0("result/",trait,"_meta.txt"),
                     sep = "\t")
}


