

#设置当前工作路径
#Rsrudio打开该文件，根据R代码所在位置，设置所在文件夹为工作路径
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#加载包
library(ggplot2)
library(scales)
library(data.table)
library(dplyr)
library(tidyr)

#参数设置
inputFile=c("EXERCISE_Fixed_hg19", "T2D_Fixed_hg19")  #性状名
width=10   #图片宽度
height=8   #图片高度

# 绘制GWAS loci with >= 1 colocalizing e/QTLs ----------------------------------
#读入数据
data <- fread("../23.pre_data_for_coloc_plot/all_Num_GWAS_loci_coloc.txt")
#筛选构建数据框
data <- data %>% filter(Trait %in% inputFile)

# 转换函数
transform_data <- function(df) {
  # 筛选需要保留的行（去掉Average和Total loci）
  df <- df[!df$Trait %in% c("Average", "Total loci"), ]
  
  # 创建新数据框
  result <- data.frame(
    Trait = rep(df$Trait, each = 3),
    Category = rep(c("eGenes", "sGenes", "Union"), times = length(unique(inputFile))),
    Count = c(rbind(df$loci_greater_than_1_colocalizing_eGene_union, 
                    df$loci_greater_than_1_colocalizing_sGene_union,
                    df$loci_greater_than_1_colocalizing_eGene_sGene_union)),
    Proportion = c(rbind(df$loci_greater_than_1_colocalizing_eGene_union_percentage, 
                         df$loci_greater_than_1_colocalizing_sGene_union_percentage,
                         df$loci_greater_than_1_colocalizing_eGene_sGene_union_percentage))
  )
  
  # 添加百分比标签
  result$Proportion_label <- paste0(round(result$Proportion * 100, 1), "%")
  
  return(result)
}

# 执行转换
data <- transform_data(data)

# 绘图
p1 <- ggplot(data, aes(x = Category)) +
  geom_bar(aes(y = Count, fill = Category), 
           stat = "identity", width = 0.7, alpha = 0.8) +
  geom_text(aes(y = Count, label = Count), 
            vjust = -0.5, size = 3.5, fontface = "bold") +
  geom_line(aes(y = Proportion * max(Count) / 0.7, group = Trait), 
            color = "gray30", linewidth = 0.8) +
  geom_point(aes(y = Proportion * max(Count) / 0.7, color = Category), 
             size = 3, show.legend = FALSE) +
  geom_text(aes(y = Proportion * max(Count) / 0.7, label = Proportion_label),
            vjust = -1, size = 3, color = "black") +
  scale_y_continuous(
    name = "Count",
    sec.axis = sec_axis(~ . * 0.7 / max(data$Count), 
                        labels = percent, 
                        name = "Proportion")
  ) +
  facet_wrap(~ Trait, ncol = 5) +
  scale_fill_manual(values = c("red","blue","deepskyblue")) +
  scale_color_manual(values = c("red","blue","deepskyblue")) +
  labs(title = "GWAS loci with >= 1 colocalizing e/QTLs") +
  # theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    strip.text = element_text(face = "bold"),
    panel.grid.major.x = element_blank(),
    axis.text.x = element_text(angle = 0, hjust = 1),
    axis.title.x = element_blank(),  # 移除X轴标题
    legend.position = "top",          # 图例在上方
    # legend.direction = "horizontal",  # 水平排列
    legend.title = element_blank(),   # 隐藏图例标题
    legend.box.spacing = unit(0.1, "cm")
  )

#打印
print(p1)
#保存图片
ggsave("Num_GWAS_loci_coloc.pdf", p1, width = width, height = height)
#保存数据
fwrite(data, "plot_for_coloc.txt", sep = "\t")


# 绘制colocalizing genes per locus---------- -----------------------------------
#读入数据
dat <- fread("../23.pre_data_for_coloc_plot/all_NumQTL_coloc_locus.txt")

# 筛选POAG_cross和POAG_EUR数据，并转换数据格式
data_long <- dat %>%
  filter(Trait %in% c("EXERCISE_Fixed_hg19", "T2D_Fixed_hg19")) %>%
  pivot_longer(
    cols = c(eGenes, sGenes, eGene_sGene_union),
    names_to = "Gene_Type",
    values_to = "Count"
  ) %>%
  mutate(
    Gene_Type = factor(Gene_Type, 
                       levels = c("eGenes", "sGenes", "eGene_sGene_union"),
                       labels = c("eGenes", "sGenes", "union")),
    Trait = factor(Trait, levels = c("EXERCISE_Fixed_hg19", "T2D_Fixed_hg19"))
  )

# 绘制小提琴图
p2 <- ggplot(data_long, aes(x = Gene_Type, y = Count, fill = Gene_Type)) +
  geom_violin(trim = FALSE, alpha = 0.7) +
  geom_boxplot(width = 0.1, fill = "white", outlier.shape = NA) +  # 添加箱线图显示中位数
  facet_wrap(~ Trait, ncol = 5) +
  # theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1),
    plot.title = element_text(hjust = 0.5, face = "bold"),
    legend.position = "none"  # 图例与x轴标签重复，故隐藏
  ) +
  scale_fill_manual(values = c("eGenes" = "red", "sGenes" = "blue", "union" = "deepskyblue"))+
  labs(title = "colocalizing genes per locus") +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    strip.text = element_text(face = "bold"),
    panel.grid.major.x = element_blank(),
    axis.text.x = element_text(angle = 0, hjust = 1),
    axis.title.x = element_blank(),  # 移除X轴标题
    legend.position = "top",          # 图例在上方
    # legend.direction = "horizontal",  # 水平排列
    legend.title = element_blank(),   # 隐藏图例标题
    legend.box.spacing = unit(0.1, "cm")
  )

#打印
print(p2)
#保存图片
ggsave("colocalizing_genes_per_locus.pdf", p2, width = width, height = height)
=