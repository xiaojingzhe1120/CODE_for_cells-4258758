

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#下载以及加载包
library(Fast2TWAS)
library(data.table)

#参数设置
inputFile=c("EXERCISE_Fixed_hg19", "T2D_Fixed_hg19")  #性状名
#指定lead SNP的上下游范围
wind_size = 50000
#基因组参考人群
ref_pop="g1000_eur"    #c("g1000_eur","g1000_afr","g1000_amr","g1000_eas","g1000_sas")
#读入来自GTEx v8的组织列表文件
gtex_tissue_names <- c(
  "Adipose_Subcutaneous","Adipose_Visceral_Omentum","Heart_Atrial_Appendage",
  "Heart_Left_Ventricle","Kidney_Cortex","Liver","Lung","Pancreas",
  "Muscle_Skeletal","Whole_Blood"
)
#指定fastenloc_coloc_run线程数
thread = 8

################################################################################
#############循环构建eCAVIAR输入文件，该步骤耗时较长，注意掌握时间##############
################################################################################
write(x = "", file = "18.fastenloc.log", append = F)
for (trait in inputFile) {
  #列出GenomicRiskLoci.txt文件位置
  GenomicRiskLoci_dir <- list.files(
    path = paste0("../13.fuma/",trait,"/"),
    pattern = "^FUMA.*",
    full.names = TRUE,
    include.dirs = TRUE
  ) %>% .[file.info(.)$isdir]
  #读入FUMA风险基因座结果
  GenomicRiskLoci=fread(paste0(GenomicRiskLoci_dir,"/GenomicRiskLoci.txt"))
  
  for (snp in GenomicRiskLoci$rsID) {
    #显示运行信息  
    i=which(snp == GenomicRiskLoci$rsID)
    message("\n当前性状：",trait,"，当前第",i,"个GenomicRiskLoci,LeadSNPs：",GenomicRiskLoci[i,]$rsID)
    
    #eQTL和sQTL循环
    for (qtl_type in c("eQTL","sQTL")) {
      #gtex_tissue循环
      for (tissue in gtex_tissue_names) {  
        #显示运行信息  
        message("\n当前性状：",trait,"，当前QTL类型：",qtl_type,"，当前组织：",tissue,"，当前lead SNP：",snp)
        
        #trait相对应GWAS文件夹
        trait_qtl_type_dir=paste0("../17.pre_fastenloc/",trait,"/")
        
        gwas_qtl_all_file <- paste0(trait_qtl_type_dir,"/",snp,"_",trait,"_",wind_size/1000,"kb_",ref_pop,"_markers_QTL_gwas_",tissue,"_",qtl_type,".fastenloc.txt")
        if (!file.exists(gwas_qtl_all_file)) {
          line=paste0("当前性状：",trait,"，当前lead SNP：",snp,"，当前QTL类型：",qtl_type,"，当前组织：",tissue,"，不存在文件")
          message(line)
          write(x = line, file = "18.fastenloc.log", append = T)
          next
        }
        gwas_qtl_all_data <- fread(gwas_qtl_all_file)
        total_variant <- nrow(gwas_qtl_all_data)
        outname_file <- paste0(snp,"_",trait,"_",wind_size/1000,"kb_",ref_pop,"_markers_QTL_gwas_",tissue,"_",qtl_type,".fastenloc_result")
        #fastenloc分析
        fastenloc_coloc_run(summary = gwas_qtl_all_file,
                            total_variant = total_variant,
                            thread = thread,
                            is_coloc_default_prior = T,
                            outname = outname_file)

      }  
    }
  }
}
