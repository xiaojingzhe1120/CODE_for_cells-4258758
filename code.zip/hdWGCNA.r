setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
rm(list = ls()); gc()
# 1) Bioconductor 管理器（装 GeneOverlap 用）
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")

# 2) 安装缺的依赖
# UCell 在 CRAN；GeneOverlap 在 Bioconductor

# 3)（可选）常见依赖，已有会跳过
for (pkg in c("Seurat", "Matrix", "Rcpp", "RcppArmadillo", "irlba", "dplyr", "ggplot2")) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
}

# 4) 重新安装 hdWGCNA（不强制更新一堆包，减少冲突）
if (!requireNamespace("remotes", quietly = TRUE)) install.packages("remotes")
Sys.setenv(R_REMOTES_NO_ERRORS_FROM_WARNINGS="true")
#remotes::install_github("smorabit/hdWGCNA", upgrade = "never")

# 5) 验证
library(UCell)
library(GeneOverlap)
library(hdWGCNA)
cat("✅ UCell / GeneOverlap / hdWGCNA 安装完成并可用。\n")
library(cowplot)
# 5) 加载验证
library(WGCNA)
library(hdWGCNA)
cat("✅ WGCNA 与 hdWGCNA 已安装并可用。\n")


setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

theme_set(theme_cowplot())

### 读取Seurat数据
sc_data <- readRDS("/mnt/e/26.5scRNA/SM/After_annotated_mmRNA_harmony.rds")

### 设置要研究的细胞类型
cell_type <- "FAP"  # 例如: "B_cells", "Macrophages", "Neutrophils"等

### 加载包
library(Fast2TWAS)
library(Seurat)
library(tidyverse)
library(cowplot)
library(patchwork)
library(WGCNA)
library(hdWGCNA)
library(UCell)
library(scales)


library(ggradar)

# 设置随机种子
set.seed(12345)

# 查看当前 hdWGCNA 使用的线程数
nThreads <- allowWGCNAThreads()
print(paste("当前 WGCNA 使用的线程数:", nThreads))
# 线程选择
enableWGCNAThreads(nThreads = 13)

# 将单细胞对象重命名为seurat_obj以简化后续代码
seurat_obj <- sc_data

### 配置WGCNA分析所需的Seurat对象及基因选择
seurat_obj <- SetupForWGCNA(
  seurat_obj,
  gene_select = "fraction", 
  fraction = 0.05,
  wgcna_name = "analysis"
)

# 构建元细胞
seurat_obj <- MetacellsByGroups(
  seurat_obj = seurat_obj,
  group.by = c("cell_type_label", "intervention_group"),
  reduction = 'harmony',
  k = 25,
  max_shared = 10,
  ident.group = 'cell_type_label'
)

# 归一化
seurat_obj <- NormalizeMetacells(seurat_obj)
seurat_obj <- ScaleMetacells(seurat_obj, features = VariableFeatures(seurat_obj))

# 执行主成分析
seurat_obj <- RunPCAMetacells(seurat_obj, features = VariableFeatures(seurat_obj))

# 校正批次效应
seurat_obj <- RunHarmonyMetacells(seurat_obj, group.by.vars = 'intervention_group')

# 行共表达分析
seurat_obj <- SetDatExpr(
  seurat_obj,
  group_name = cell_type,  
  group.by = 'cell_type_label',
  assay = 'RNA',
  slot = 'data'
)

# 软阈值
seurat_obj <- TestSoftPowers(
  seurat_obj,
  networkType = 'signed'
)

# 可视化软阈值测试结果
plot_list <- PlotSoftPowers(seurat_obj)
p5 <- wrap_plots(plot_list, ncol = 2)
ggsave(paste0(cell_type, "_soft_power_test.pdf"), plot = p5, width = 9, height = 6)

# 根据软阈值测试结果构建共表达网络
seurat_obj <- ConstructNetwork(
  seurat_obj, 
  soft_power = 4,  # 根据实际情况调整
  setDatExpr = FALSE,
  tom_name = cell_type,
  overwrite_tom = TRUE# 使用用户指定的细胞类型
)

# 绘制共表达模块树状图
pdf(file = paste0(cell_type, "_module_dendrogram.pdf"), width = 9, height = 5)
PlotDendrogram(seurat_obj, main = paste0(cell_type, ' hdWGCNA Dendrogram'))
dev.off()

# 获取拓扑重叠矩阵
TOM <- GetTOM(seurat_obj)

# 数据标准化
seurat_obj <- ScaleData(seurat_obj, features = VariableFeatures(seurat_obj))

# 计算模块特征基因和连通性
seurat_obj <- ModuleEigengenes(seurat_obj, group.by.vars = "intervention_group")

seurat_obj <- ModuleConnectivity(
  seurat_obj,
  group.by = 'cell_type_label', 
  group_name = cell_type  
)

# 重命名模块
seurat_obj <- ResetModuleNames(seurat_obj, new_name = paste0(cell_type, "-M"))

p7 <- PlotKMEs(seurat_obj, ncol = 3)
ggsave(paste0(cell_type, "_module_kME_plot.pdf"), plot = p7, width = 9, height = 5)


modules <- GetModules(seurat_obj) %>% subset(module != 'grey')
head(modules[, 1:6])

# 获取各模块的核心基因
hub_df <- GetHubGenes(seurat_obj, n_hubs = 10)
View(hub_df)

# 绘制模块特征基因表达图
plot_list <- ModuleFeaturePlot(seurat_obj, features = 'hMEs', order = TRUE)
p8 <- wrap_plots(plot_list, ncol = 3)
ggsave(paste0(cell_type, "_module_eigengene_expression.pdf"), plot = p8, width = 9, height = 5)

# 绘制模块相关性图
pdf(file = paste0(cell_type, "_module_correlogram.pdf"), width = 8, height = 5)
ModuleCorrelogram(seurat_obj)
dev.off()

# 提取模块特征基因数据
MEs <- GetMEs(seurat_obj, harmonized = TRUE)
modules <- GetModules(seurat_obj)
mods <- levels(modules$module)
mods <- mods[mods != 'grey']

# 将特征基因数据添加至元数据
seurat_obj@meta.data <- cbind(seurat_obj@meta.data, MEs)

# 绘制模块表达气泡图
p11 <- DotPlot(seurat_obj, features = mods, group.by = 'cell_type_label')
p12 <- p11 +
  coord_flip() +
  RotatedAxis() +
  scale_color_gradient2(high = 'red', mid = 'grey95', low = 'blue')
ggsave(paste0(cell_type, "_module_expression_dotplot.pdf"), plot = p12, width = 8, height = 5)

# 绘制特定模块的小提琴图
p13 <- VlnPlot(
  seurat_obj,
  features = paste0(cell_type, '-M1'),
  group.by = 'cell_type_label',
  pt.size = 0
)
ggsave(paste0(cell_type, "_module_violin_plot.pdf"), plot = p13, width = 8, height = 5)

# 绘制带箱线图的小提琴图
p14 <- p13 + geom_boxplot(width = 0.25, fill = 'white') +
  xlab('') + 
  ylab('hME') + 
  NoLegend()
ggsave(paste0(cell_type, "_violin_with_boxplot.pdf"), plot = p14, width = 8, height = 5)

# 绘制模块基因网络图
ModuleNetworkPlot(seurat_obj, outdir = paste0(cell_type, '_ModuleNetworks'))

ModuleNetworkPlot(
  seurat_obj, 
  outdir = paste0(cell_type, '_ModuleNetworks2'),
  n_inner = 20,
  n_outer = 30,
  n_conns = Inf,
  plot_size = c(10, 10),
  vertex.label.cex = 1
)

# 导出核心基因
gokegg_hub_df <- GetHubGenes(seurat_obj, n_hubs = 50)
filtered_gokegg_hub_df <- gokegg_hub_df[grepl("M[12]$", gokegg_hub_df$module), ]
write.table(filtered_gokegg_hub_df, paste0(cell_type, '_hub_genes_for_enrichment.txt'), 
            sep = "\t", quote = FALSE, row.names = FALSE)

library(clusterProfiler)
library(org.Mm.eg.db)
library(dplyr)
library(ggplot2)
library(enrichplot)

# ================= GO-BP 富集（按模块） =================
ego_list <- list()

for (mod in names(gene_entrez_by_module)) {
  genes_entrez <- gene_entrez_by_module[[mod]]
  if (length(genes_entrez) < 5) next  # 太少跳过
  
  ego <- enrichGO(
    gene          = genes_entrez,
    OrgDb         = org.Mm.eg.db,
    keyType       = "ENTREZID",
    ont           = "BP",
    pAdjustMethod = "BH",
    pvalueCutoff  = 0.05,
    qvalueCutoff  = 0.2,
    readable      = TRUE
  )
  
  ego_list[[mod]] <- ego
  
  if (!is.null(ego) && nrow(as.data.frame(ego)) > 0) {
    out_tab <- as.data.frame(ego)
    out_tab$module <- mod
    write.csv(out_tab,
              file = paste0(mod, "_AllGenes_GO_BP_enrichment.csv"),
              row.names = FALSE)
  }
}

# 画每个模块的 GO dotplot
for (mod in names(ego_list)) {
  ego <- ego_list[[mod]]
  if (is.null(ego) || nrow(as.data.frame(ego)) == 0) next
  
  p <- dotplot(ego, showCategory = 20) +
    ggtitle(paste0(mod, " GO-BP enrichment (all genes)"))
  
  ggsave(paste0(mod, "_AllGenes_GO_BP_dotplot.pdf"),
         plot = p, width = 7, height = 6)
}

# ================= KEGG 富集（按模块） =================
ekegg_list <- list()

for (mod in names(gene_entrez_by_module)) {
  genes_entrez <- gene_entrez_by_module[[mod]]
  if (length(genes_entrez) < 5) next
  
  ekegg <- enrichKEGG(
    gene          = genes_entrez,
    organism      = "mmu",
    pvalueCutoff  = 0.05,
    qvalueCutoff  = 0.2
  )
  
  if (!is.null(ekegg) && nrow(as.data.frame(ekegg)) > 0) {
    ekegg <- setReadable(ekegg, OrgDb = org.Mm.eg.db, keyType = "ENTREZID")
  }
  
  ekegg_list[[mod]] <- ekegg
  
  if (!is.null(ekegg) && nrow(as.data.frame(ekegg)) > 0) {
    out_tab <- as.data.frame(ekegg)
    out_tab$module <- mod
    write.csv(out_tab,
              file = paste0(mod, "_AllGenes_KEGG_enrichment.csv"),
              row.names = FALSE)
  }
}

for (mod in names(ekegg_list)) {
  ekegg <- ekegg_list[[mod]]
  if (is.null(ekegg) || nrow(as.data.frame(ekegg)) == 0) next
  
  p <- dotplot(ekegg, showCategory = 20) +
    ggtitle(paste0(mod, " KEGG enrichment (all genes)"))
  
  ggsave(paste0(mod, "_AllGenes_KEGG_dotplot.pdf"),
         plot = p, width = 7, height = 6)
}

# ================= Reactome 富集（按模块） =================
if (!requireNamespace("ReactomePA", quietly = TRUE)) {
  BiocManager::install("ReactomePA")
}
library(ReactomePA)

react_list <- list()

for (mod in names(gene_entrez_by_module)) {
  genes_entrez <- gene_entrez_by_module[[mod]]
  if (length(genes_entrez) < 5) next
  
  er <- enrichPathway(
    gene          = genes_entrez,
    organism      = "mouse",
    pvalueCutoff  = 0.05,
    qvalueCutoff  = 0.2,
    pAdjustMethod = "BH",
    readable      = TRUE
  )
  
  react_list[[mod]] <- er
  
  if (!is.null(er) && nrow(as.data.frame(er)) > 0) {
    out_tab <- as.data.frame(er)
    out_tab$module <- mod
    write.csv(out_tab,
              file = paste0(mod, "_AllGenes_Reactome_enrichment.csv"),
              row.names = FALSE)
  }
}

for (mod in names(react_list)) {
  er <- react_list[[mod]]
  if (is.null(er) || nrow(as.data.frame(er)) == 0) next
  
  p <- dotplot(er, showCategory = 20) +
    ggtitle(paste0(mod, " Reactome enrichment (all genes)"))
  
  ggsave(paste0(mod, "_AllGenes_Reactome_dotplot.pdf"),
         plot = p, width = 7, height = 9)
}

