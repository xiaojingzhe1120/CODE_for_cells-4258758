
#设置当前工作路径
#Rsrudio打开该文件，根据R代码所在位置，设置所在文件夹为工作路径
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#加载包
library(Fast2TWAS)

#参数设置
inputFile=c("EXERCISE_Fixed_hg19", "T2D_Fixed_hg19")  #性状名
#hdf5_path文件路径
hdf5_path="../34.pre_gsMap/ST/E16.5_E1S1.MOSTA.h5ad" #ST文件路径
annotation='annotation'   #根据32.pre_gsMap.R文件中的注释文件进行设置
data_layer='count'        #根据32.pre_gsMap.R文件中的数据层进行设置 

# 生成gsMap输入文件格式 --------------------------------------------------------
for (trait in inputFile) {
  gsMap_format_sumstats_run(sumstats=paste0("../07.hg19Tohg38/",trait,"_hg38_qc.txt"),
                            snp="SNP",
                            a1="effect_allele",
                            a2="other_allele",
                            info=NULL,
                            beta="beta",
                            se="se",
                            p="pval",
                            frq="eaf",
                            n="N",
                            chr="CHR",
                            pos="BP",
                            dbsnp=NULL,
                            chunksize="500000",
                            format="gsMap",
                            info_min=NULL,
                            maf_min=NULL,
                            outname=trait) 
  
}


# gsMap快速模式运行 ------------------------------------------------------------
for (trait in inputFile) {
  gsMap_quick_mode_run(sample_name=gsub(".h5ad","",basename(hdf5_path)),
                       gsMap_resource_dir='gsMap_resource',
                       hdf5_path=hdf5_path,
                       annotation=annotation,        #根据32.pre_gsMap.R文件中的注释文件进行设置
                       data_layer=data_layer,        #根据32.pre_gsMap.R文件中的数据层进行设置 
                       trait_name=trait,
                       sumstats_file=paste0('./result/',trait,".sumstats.gz"),
                       sumstats_config_file=NULL,
                       homolog_file='./gsMap_resource/homologs/mouse_human_homologs.txt', 
                       max_processes=parallel::detectCores()/2, #调用CPU一半线程数
                       latent_representation=NULL,
                       num_neighbour=NULL,
                       num_neighbour_spatial=NULL,
                       gM_slices=NULL,
                       is_pearson_residuals=FALSE,
                       argsfile=NULL)
}  
