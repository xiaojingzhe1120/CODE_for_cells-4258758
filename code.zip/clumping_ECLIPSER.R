

#设置当前工作路径
#Rsrudio打开该文件，根据R代码所在位置，设置所在文件夹为工作路径
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#加载包
library(Fast2TWAS)

#参数设置
#设置significant_traits文件路径
significant_traits_file <- "../27.pre_data_ECLIPSER/demo_traits.txt"

# 创建ECLIPSER的python环境 -----------------------------------------------------
ECLIPSER_py_install(is_help = T, 
                    force = FALSE)



traits <- "/mnt/e/03.reference/ECLIPSER/GWASvar2gene_open_targets_trait_table.tsv.utf8"
proxy  <- "/mnt/e/03.reference/ECLIPSER/GWASvar2gene_open_targets_proxy_table.tsv.utf8"
eqtl   <- "/mnt/e/03.reference/ECLIPSER/GWASvar2gene_open_targets_eQTL_table.tsv.utf8"
sqtl   <- "/mnt/e/03.reference/ECLIPSER/GWASvar2gene_open_targets_sQTL_table.tsv.utf8"

ECLIPSER_clumping_run(
  proxy_table = proxy, traits_table = traits,
  eQTL_table  = eqtl,  sQTL_table  = sqtl,
  significant_traits = significant_traits_file
)






# Perform LD clumping of GWAS variants with 'clumping.py' ----------------------
ECLIPSER_clumping_run(proxy_table = "../03.reference/ECLIPSER/GWASvar2gene_open_targets_proxy_table.tsv",
                      traits_table = "../03.reference/ECLIPSER/GWASvar2gene_open_targets_trait_table.tsv",
                      eQTL_table = "../03.reference/ECLIPSER/GWASvar2gene_open_targets_eQTL_table.tsv",
                      sQTL_table = "../03.reference/ECLIPSER/GWASvar2gene_open_targets_sQTL_table.tsv",
                      # opentarget = "../03.reference/ECLIPSER/OpenTargetsGenetics_variant_and_gene_table_071620.csv",
                      significant_traits = significant_traits_file,
                      # ancestry = "EUR",
                      treat_sig_traits_as_one = NULL
                      )



