
#设置当前工作路径
#Rsrudio打开该文件，根据R代码所在位置，设置所在文件夹为工作路径
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#清除一切变量
rm(list=ls())
#释放不再使用的内存
gc()
#显式路径
getwd()
#显示R包安装位置
.libPaths()

#加载包
library(Fast2TWAS)

#参数设置
inputFile=c("EXERCISE_ukb-b-8764.vcf.gz","EXERCISE_ebi-a-GCST006100.vcf.gz")  #性状名
reticulate::use_python("/home/wsl/miniconda3/bin/python", required = TRUE)
library(reticulate)

# GTEx_Analysis_v8_eQTL --------------------------------------------------------
# 循环进行
for (trait in inputFile) {
  for (qtl_type in c("best_eqtl")) {
  QTLEnrich_run(gwas_file=paste0("../07.hg19Tohg38/",trait,"_hg38_qc_QTLEnrich.txt"),
                qtl_directory="../03.reference/QTLEnrich/GTEx_Analysis_v8_eQTL/",
                file_name=".v8.egenes.txt.gz",
                qtl_type=qtl_type,
                confounders_table="../03.reference/QTLEnrich/GTEx_v8_Confounders_Table_49Tiss_Global.txt.gz",
                null_table="../03.reference/QTLEnrich/GTEx_v8_Null_Table_49Tiss_Global.txt.gz",
                is_subset_genes=TRUE,
                is_compute_tss_distance=TRUE,
                is_keep_gene_id_suffix=TRUE,
                is_keep_null_variants=TRUE,
                is_keep_pvalue_matrix=TRUE,
                gencode_file="../03.reference/QTLEnrich/GENCODE_26_df.txt",
                null_option=NULL,
                genome_build=NULL,
                trait_name=trait,
                qtl_q_value=NULL,
                gwas_p_value=NULL,
                independent_ranking=NULL,
                lambda_factor=NULL,
                lower_bound_permutations=NULL,
                upper_bound_permutations=NULL,
                num_quantiles=NULL,
                tissue_names=NULL,
                is_subset_tissues=FALSE,
                exp_label=trait,
                is_GeneEnrich_input=TRUE,
                eGenes_directory=NULL,
                eGenes_file_name=NULL,
                flag_options=NULL,
                is_help=FALSE,
                force=FALSE)
  }
}
